package com.book;

public class Book {
	private String booktitile;
	private float bookprice;
	public String getBooktitile() {
		return booktitile;
	}
	public void setBooktitile(String booktitile) {
		this.booktitile = booktitile;
	}
	public float getBookprice() {
		return bookprice;
	}
	public void setBookprice(float price) {
		this.bookprice = price;
	}

}

